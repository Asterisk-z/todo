<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    
                    <div class="row">
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6">
                                <div class="card my-3">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($task->title); ?></h5>
                                        <p class="card-text"><?php echo e($task->description); ?></p>
                                        <p class="card-text text-danger text-bold">Deadline : <?php echo e($task->end_at->format('l jS \\of F Y h:i A')); ?></p>
                                        <a href="#" class="btn btn-success btn-sm">Completed</a>
                                    </div>
                                </div>
                            </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LEARN\LARAVEL\TODOLIST\resources\views/home.blade.php ENDPATH**/ ?>